You can add all your dot files ( .bash_aliases, .vimrc, .gitconfig, etc), to the puphpet/files/dot/ folder 
    that will appear after you extract your generated zip file.

During initial startup, they will automatically be copied into the VM. There is a sample .bashrc
    file there for you to start with - overwrite at will!
